<?php
App::uses('InventariomovimientosController', 'Controller');

/**
 * InventariomovimientosController Test Case
 *
 */
class InventariomovimientosControllerTest extends ControllerTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.inventariomovimiento',
		'app.empresa',
		'app.direpai',
		'app.direprovincia',
		'app.empresasurcusale',
		'app.user',
		'app.role',
		'app.rolemodulo',
		'app.modulo',
		'app.almacentipo',
		'app.almacene',
		'app.almacenproducto',
		'app.almacenmarca',
		'app.almacenmarcadetalle',
		'app.almacenmateriale',
		'app.almacenproductodetalle',
		'app.almacentipofunte',
		'app.almacenefunte',
		'app.ordenventa',
		'app.userventa',
		'app.inventariomovimateriale',
		'app.usermovi'
	);

/**
 * testIndex method
 *
 * @return void
 */
	public function testIndex() {
		$this->markTestIncomplete('testIndex not implemented.');
	}

/**
 * testView method
 *
 * @return void
 */
	public function testView() {
		$this->markTestIncomplete('testView not implemented.');
	}

/**
 * testAdd method
 *
 * @return void
 */
	public function testAdd() {
		$this->markTestIncomplete('testAdd not implemented.');
	}

/**
 * testEdit method
 *
 * @return void
 */
	public function testEdit() {
		$this->markTestIncomplete('testEdit not implemented.');
	}

/**
 * testDelete method
 *
 * @return void
 */
	public function testDelete() {
		$this->markTestIncomplete('testDelete not implemented.');
	}

}
